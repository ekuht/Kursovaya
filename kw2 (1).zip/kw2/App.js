import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import StepsScreen from './src/screens/StepsScreen';
import TrackCreateScreen from './src/screens/TrackCreateScreen';
import AcauntScreen from './src/screens/AcauntScreen';
import { setNavigator } from './src/navigationRef';
import ResolveAuthScreen from './src/screens/ResolveAuthScreen';
import { Provider as LocationProvider } from './src/context/LocationContext';
import { Provider as TrackProvider } from './src/context/TrackContext';
import { FontAwesome } from '@expo/vector-icons';

const trackListFlow = createStackNavigator({
  AcauntScreen,
})

trackListFlow.navigationOptions = {
  title: "User",
  tabBarIcon: <FontAwesome name="th-list" size={20} color="black" />

}

const switchNavigator = createSwitchNavigator({
 
  mainFlow: createBottomTabNavigator({
    trackListFlow,
    TrackCreateScreen,
    StepsScreen,
  })
});

const App = createAppContainer(switchNavigator);

export default () => {
  return (
    <TrackProvider>
      <LocationProvider>
        
          <App ref={(navigator) => setNavigator(navigator)}/>  
        
      </LocationProvider>
    </TrackProvider>
  )
}