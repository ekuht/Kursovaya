import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native';

export default class Profile extends Component {

  render() {
    return (
      <View style={styles.container}>
          <View style={styles.header}></View>
          <Image style={styles.avatar} source={{uri: 'https://st.depositphotos.com/1779253/5140/v/600/depositphotos_51405259-stock-illustration-male-avatar-profile-picture-use.jpg'}}/>
          <View style={styles.body}>
           <Text style={styles.text}>Kuhta Konstantin</Text>  
            <View style={styles.bodyContent}>
              <TouchableOpacity style={styles.buttonContainer}>
                <Text>Weight:75kg</Text>  
              </TouchableOpacity>              
              <TouchableOpacity style={styles.buttonContainer}>
                <Text>Growth: 185cm</Text> 
              </TouchableOpacity>
            </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  header:{
    backgroundColor: "#00BFFF",
    height:200,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 63,
    borderWidth: 4,
    borderColor: "white",
    marginBottom:10,
    alignSelf:'center',
    position: 'absolute',
    marginTop:130
  },

  body:{
    marginTop:40,
    fontFamily: "Roboto"
  },
  bodyContent: {
    flex: 1,
    alignItems: 'center',
    padding:30,
    fontFamily: "Roboto"
  },
  buttonContainer: {
    marginTop:10,
    height:45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    color:'FFF',
    marginBottom:20,
    width:250,
    fontFamily: "Roboto",

    backgroundColor: "#00BFFF",
  },
  text:{
    alignSelf:'center',
    fontFamily: "Roboto",
    fontSize: 20,
    
  },
});