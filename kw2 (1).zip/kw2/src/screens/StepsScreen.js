import React, { useContext,useEffect, useState } from 'react';
import { View, Text, StyleSheet, ImageBackground,Dimensions,} from 'react-native';
import { Button } from 'react-native-elements';
import { SafeAreaView } from 'react-navigation';
import Spacer from '../components/Spacer';
import { FontAwesome } from '@expo/vector-icons'; 
import { StatusBar } from "expo-status-bar";
import { Pedometer } from "expo-sensors";

import CircularProgress from "react-native-circular-progress-indicator";
const AccountScreen = () => {
    const [PedomaterAvailability, SetPedomaterAvailability] = useState("");

 const [StepCount, SetStepCount] = useState(1500);

 

 var WindowHeight = Dimensions.get("window").height;

 

 var  Dist = StepCount / 1300;

 var DistanceCovered = Dist.toFixed(4);

 

 var cal = DistanceCovered * 60;

 var caloriesBurnt = cal.toFixed(4);

 React.useEffect(() => {

   subscribe();

 }, []);

 

 subscribe = () => {

   const subscription = Pedometer.watchStepCount((result) => {

     SetStepCount(result.steps);

   });

 

   Pedometer.isAvailableAsync().then(

     (result) => {

       SetPedomaterAvailability(String(result));

     },

     (error) => {

       SetPedomaterAvailability(error);

     }

   );

 };

 

    return(
      <View style={styles.container}>

      <View style={{ flex: 0.5 }}></View>


      

       <View style={{ flex: 2 }}>

         <CircularProgress

           value={StepCount}

           maxValue={6500}

           radius={160}

           textColor={"#00BFFF"}

           activeStrokeColor={"#00BFFF"}

           inActiveStrokeColor={"#00BFFF"}

           inActiveStrokeOpacity={0.5}

           inActiveStrokeWidth={40}

           activeStrokeWidth={40}

           title={"Step Count"}

           titleColor={"#00BFFF"}

           titleStyle={{ fontWeight: "bold" }}
            
         />

       </View>

 

       <View style={{ flex: 1, justifyContent: "center" }}>

         <View style={{ flex: 1 }}>

           <Text

             style={[

               styles.textDesign,

               { paddingLeft: 20, marginLeft: '3.5%' },

             ]}

           >

             Target : 6500 steps(5kms)

           </Text>

         </View>

 

         <View style={{ flex: 1 }}>

           <Text

             style={[

               styles.textDesign,

               { width: "93%", paddingLeft: 20, marginLeft: '3.5%' },

             ]}

           >

             Distance Covered : {DistanceCovered} km

           </Text>

         </View>

 

         <View style={{ flex: 1 }}>

           <Text

             style={[

               styles.textDesign,

               {  paddingLeft: 20, marginLeft: '3.5%' },

             ]}

           >

             Calories Burnt : {caloriesBurnt}

           </Text>

         </View>

 

         <StatusBar style="auto" />

       </View>


   </View>
    );
  
};


AccountScreen.navigationOptions = {
    title: 'steps',
    tabBarIcon: <FontAwesome name="gear" size={20} color="black" />
};

const styles = StyleSheet.create({

 container: {

   flex: 1,

   backgroundColor: "#fff",

 },

 headingDesign: {

   backgroundColor: "#00BFFF",

 

   alignSelf: "center",

   fontSize: 20,

   color: "white",

   fontWeight: "bold",

   fontFamily: "Roboto",

 },

 textDesign: {

   backgroundColor: "#00BFFF",

   height: 30,

   width : '95%',

   borderColor: "white",

   borderWidth: 1,

   borderRadius: 20,

   overflow: "hidden",

   fontSize: 20,

   color: "white",

   fontWeight: "bold",

   fontFamily: "Roboto",

 },

});;

export default AccountScreen;