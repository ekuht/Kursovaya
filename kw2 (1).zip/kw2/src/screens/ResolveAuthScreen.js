import React, {useContext, useEffect } from 'react';

const ResolveAuthScreen = () => {
    useEffect(()=>{
        tryLocalSignin();
    },[])
    return null;
}

export default ResolveAuthScreen;